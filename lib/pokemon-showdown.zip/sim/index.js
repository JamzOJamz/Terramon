"use strict";var p=Object.defineProperty,T=Object.getOwnPropertyDescriptor,g=Object.getOwnPropertyNames,k=Object.prototype.hasOwnProperty,n=(e,r)=>{for(var t in r)p(e,t,{get:r[t],enumerable:!0})},f=(e,r,t,a)=>{if(r&&"object"==typeof r||"function"==typeof r)for(let o of g(r))!k.call(e,o)&&o!==t&&p(e,o,{get:()=>r[o],enumerable:!(a=T(r,o))||a.enumerable});return e},l=(e,r,t)=>(f(e,r,"default"),t&&f(t,r,"default")),y=e=>f(p({},"__esModule",{value:!0}),e),m={};n(m,{Battle:()=>S.Battle,BattleStream:()=>x.BattleStream,Dex:()=>a.Dex,PRNG:()=>i.PRNG,Pokemon:()=>d.Pokemon,Side:()=>s.Side,TeamValidator:()=>D.TeamValidator,Teams:()=>B.Teams,getPlayerStreams:()=>x.getPlayerStreams,toID:()=>a.toID}),module.exports=y(m);var S=require("./battle"),x=require("./battle-stream"),d=require("./pokemon"),i=require("./prng"),s=require("./side"),a=require("./dex"),B=require("./teams"),D=require("./team-validator");l(m,require("../lib"),module.exports);
/**
                                         * Simulator
                                         * Pokemon Showdown - http://pokemonshowdown.com/
                                         *
                                         * Here's where all the simulator APIs get exported for general use.
                                         * `require('pokemon-showdown')` imports from here.
                                         *
                                         * @license MIT
                                         */