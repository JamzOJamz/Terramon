"use strict";var p=Object.defineProperty;var T=Object.getOwnPropertyDescriptor;var g=Object.getOwnPropertyNames;var k=Object.prototype.hasOwnProperty;var n=(r,o)=>{for(var e in o)p(r,e,{get:o[e],enumerable:!0})},f=(r,o,e,P)=>{if(o&&typeof o=="object"||typeof o=="function")for(let t of g(o))!k.call(r,t)&&t!==e&&p(r,t,{get:()=>o[t],enumerable:!(P=T(o,t))||P.enumerable});return r},l=(r,o,e)=>(f(r,o,"default"),e&&f(e,o,"default"));var y=r=>f(p({},"__esModule",{value:!0}),r);var m={};n(m,{Battle:()=>S.Battle,BattleStream:()=>x.BattleStream,Dex:()=>a.Dex,PRNG:()=>i.PRNG,Pokemon:()=>d.Pokemon,Side:()=>s.Side,TeamValidator:()=>D.TeamValidator,Teams:()=>B.Teams,getPlayerStreams:()=>x.getPlayerStreams,toID:()=>a.toID});module.exports=y(m);var S=require("./battle"),x=require("./battle-stream"),d=require("./pokemon"),i=require("./prng"),s=require("./side"),a=require("./dex"),B=require("./teams"),D=require("./team-validator");l(m,require("../lib"),module.exports);/**
 * Simulator
 * Pokemon Showdown - http://pokemonshowdown.com/
 *
 * Here's where all the simulator APIs get exported for general use.
 * `require('pokemon-showdown')` imports from here.
 *
 * @license MIT
 */
