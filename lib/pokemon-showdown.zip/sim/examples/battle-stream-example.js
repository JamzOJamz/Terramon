"use strict";var t=require(".."),o=require("../tools/random-player-ai");
/**
                                            * Battle Stream Example
                                            * Pokemon Showdown - http://pokemonshowdown.com/
                                            *
                                            * Example of how to create AIs battling against each other.
                                            * Run this using `node build && node .sim-dist/examples/battle-stream-example`.
                                            *
                                            * @license MIT
                                            * @author Guangcong Luo <guangcongluo@gmail.com>
                                            */const e=(0,t.getPlayerStreams)(new t.BattleStream),r={formatid:"gen7customgame"},c={name:"Bot 1",team:t.Teams.pack(t.Teams.generate("gen7randombattle"))},m={name:"Bot 2",team:t.Teams.pack(t.Teams.generate("gen7randombattle"))},n=new o.RandomPlayerAI(e.p1),a=new o.RandomPlayerAI(e.p2);console.log("p1 is "+n.constructor.name),console.log("p2 is "+a.constructor.name),n.start(),a.start(),(async()=>{for await(const t of e.omniscient)console.log(t)})(),e.omniscient.write(`>start ${JSON.stringify(r)}\n>player p1 ${JSON.stringify(c)}\n>player p2 ${JSON.stringify(m)}`);