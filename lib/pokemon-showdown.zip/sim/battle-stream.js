"use strict";var l=Object.defineProperty;var d=Object.getOwnPropertyDescriptor;var g=Object.getOwnPropertyNames;var u=Object.prototype.hasOwnProperty;var b=(t,e)=>{for(var s in e)l(t,s,{get:e[s],enumerable:!0})},m=(t,e,s,r)=>{if(e&&typeof e=="object"||typeof e=="function")for(let a of g(e))!u.call(t,a)&&a!==s&&l(t,a,{get:()=>e[a],enumerable:!(r=d(e,a))||r.enumerable});return t};var f=t=>m(l({},"__esModule",{value:!0}),t);var w={};b(w,{BattlePlayer:()=>BattlePlayer,BattleStream:()=>BattleStream,BattleTextStream:()=>BattleTextStream,getPlayerStreams:()=>getPlayerStreams});module.exports=f(w);var i=require("../lib"),c=require("./teams"),o=require("./battle");/**
 * Battle Stream
 * Pokemon Showdown - http://pokemonshowdown.com/
 *
 * Supports interacting with a PS battle in Stream format.
 *
 * This format is VERY NOT FINALIZED, please do not use it directly yet.
 *
 * @license MIT
 */function splitFirst(t,e,s=1){const r=[];for(;r.length<s;){const a=t.indexOf(e);a>=0?(r.push(t.slice(0,a)),t=t.slice(a+e.length)):(r.push(t),t="")}return r.push(t),r}class BattleStream extends i.Streams.ObjectReadWriteStream{constructor(t={}){super(),this.debug=!!t.debug,this.noCatch=!!t.noCatch,this.replay=t.replay||!1,this.keepAlive=!!t.keepAlive,this.battle=null}_write(t){if(this.noCatch)this._writeLines(t);else try{this._writeLines(t)}catch(e){this.pushError(e,!0);return}this.battle&&this.battle.sendUpdates()}_writeLines(t){for(const e of t.split(`
`))if(e.startsWith(">")){const[s,r]=splitFirst(e.slice(1)," ");this._writeLine(s,r)}}pushMessage(t,e){if(this.replay){if(t==="update")if(this.replay==="spectator"){const s=(0,o.extractChannelMessages)(e,[0]);this.push(s[0].join(`
`))}else{const s=(0,o.extractChannelMessages)(e,[-1]);this.push(s[-1].join(`
`))}return}this.push(`${t}
${e}`)}_writeLine(type,message){switch(type){case"start":const options=JSON.parse(message);options.send=(t,e)=>{Array.isArray(e)&&(e=e.join(`
`)),this.pushMessage(t,e),t==="end"&&!this.keepAlive&&this.pushEnd()},this.debug&&(options.debug=!0),this.battle=new o.Battle(options);break;case"player":const[slot,optionsText]=splitFirst(message," ");this.battle.setPlayer(slot,JSON.parse(optionsText));break;case"p1":case"p2":case"p3":case"p4":message==="undo"?this.battle.undoChoice(type):this.battle.choose(type,message);break;case"forcewin":case"forcetie":this.battle.win(type==="forcewin"?message:null),message?this.battle.inputLog.push(`>forcewin ${message}`):this.battle.inputLog.push(">forcetie");break;case"forcelose":this.battle.lose(message),this.battle.inputLog.push(`>forcelose ${message}`);break;case"reseed":this.battle.resetRNG(message),this.battle.inputLog.push(`>reseed ${this.battle.prng.getSeed()}`);break;case"tiebreak":this.battle.tiebreak();break;case"chat-inputlogonly":this.battle.inputLog.push(`>chat ${message}`);break;case"chat":this.battle.inputLog.push(`>chat ${message}`),this.battle.add("chat",`${message}`);break;case"eval":const battle=this.battle;battle.inputLog.push(`>${type} ${message}`),message=message.replace(/\f/g,`
`),battle.add("",">>> "+message.replace(/\n/g,`
||`));try{const p1=battle.sides[0],p2=battle.sides[1],p3=battle.sides[2],p4=battle.sides[3],p1active=p1?.active[0],p2active=p2?.active[0],p3active=p3?.active[0],p4active=p4?.active[0],toID=battle.toID,player=t=>{if(t=toID(t),/^p[1-9]$/.test(t))return battle.sides[parseInt(t.slice(1))-1];if(/^[1-9]$/.test(t))return battle.sides[parseInt(t)-1];for(const e of battle.sides)if(toID(e.name)===t)return e;return null},pokemon=(t,e)=>(typeof t=="string"&&(t=player(t)),e=toID(e),/^[1-9]$/.test(e)?t.pokemon[parseInt(e)-1]:t.pokemon.find(s=>s.baseSpecies.id===e||s.species.id===e));let result=eval(message);result?.then?result.then(t=>{t=i.Utils.visualize(t),battle.add("","Promise -> "+t),battle.sendUpdates()},t=>{battle.add("","<<< error: "+t.message),battle.sendUpdates()}):(result=i.Utils.visualize(result),result=result.replace(/\n/g,`
||`),battle.add("","<<< "+result))}catch(t){battle.add("","<<< error: "+t.message)}break;case"requestlog":this.push(`requesteddata
${this.battle.inputLog.join(`
`)}`);break;case"requestexport":this.push(`requesteddata
${this.battle.prngSeed}
${this.battle.inputLog.join(`
`)}`);break;case"requestteam":message=message.trim();const slotNum=parseInt(message.slice(1))-1;if(isNaN(slotNum)||slotNum<0)throw new Error(`Team requested for slot ${message}, but that slot does not exist.`);const side=this.battle.sides[slotNum],team=c.Teams.pack(side.team);this.push(`requesteddata
${team}`);break;case"show-openteamsheets":this.battle.showOpenTeamSheets();break;case"version":case"version-origin":break;default:throw new Error(`Unrecognized command ">${type} ${message}"`)}}_writeEnd(){this.atEOF||this.pushEnd(),this._destroy()}_destroy(){this.battle&&this.battle.destroy()}}function getPlayerStreams(t){const e={omniscient:new i.Streams.ObjectReadWriteStream({write(s){t.write(s)},writeEnd(){return t.writeEnd()}}),spectator:new i.Streams.ObjectReadStream({read(){}}),p1:new i.Streams.ObjectReadWriteStream({write(s){t.write(s.replace(/(^|\n)/g,"$1>p1 "))}}),p2:new i.Streams.ObjectReadWriteStream({write(s){t.write(s.replace(/(^|\n)/g,"$1>p2 "))}}),p3:new i.Streams.ObjectReadWriteStream({write(s){t.write(s.replace(/(^|\n)/g,"$1>p3 "))}}),p4:new i.Streams.ObjectReadWriteStream({write(s){t.write(s.replace(/(^|\n)/g,"$1>p4 "))}})};return(async()=>{for await(const s of t){const[r,a]=splitFirst(s,`
`);switch(r){case"update":const n=(0,o.extractChannelMessages)(a,[-1,0,1,2,3,4]);e.omniscient.push(n[-1].join(`
`)),e.spectator.push(n[0].join(`
`)),e.p1.push(n[1].join(`
`)),e.p2.push(n[2].join(`
`)),e.p3.push(n[3].join(`
`)),e.p4.push(n[4].join(`
`));break;case"sideupdate":const[h,p]=splitFirst(a,`
`);e[h].push(p);break;case"end":break}}for(const s of Object.values(e))s.pushEnd()})().catch(s=>{for(const r of Object.values(e))r.pushError(s,!0)}),e}class BattlePlayer{constructor(e,s=!1){this.stream=e,this.log=[],this.debug=s}async start(){for await(const e of this.stream)this.receive(e)}receive(e){for(const s of e.split(`
`))this.receiveLine(s)}receiveLine(e){if(this.debug&&console.log(e),!e.startsWith("|"))return;const[s,r]=splitFirst(e.slice(1),"|");if(s==="request")return this.receiveRequest(JSON.parse(r));if(s==="error")return this.receiveError(new Error(r));this.log.push(e)}receiveError(e){throw e}choose(e){this.stream.write(e)}}class BattleTextStream extends i.Streams.ReadWriteStream{constructor(e){super(),this.battleStream=new BattleStream(e),this.currentMessage="",this._listen()}async _listen(){for await(let e of this.battleStream)e.endsWith(`
`)||(e+=`
`),this.push(e+`
`);this.pushEnd()}_write(e){this.currentMessage+=`${e}`;const s=this.currentMessage.lastIndexOf(`
`);s>=0&&(this.battleStream.write(this.currentMessage.slice(0,s)),this.currentMessage=this.currentMessage.slice(s+1))}_writeEnd(){return this.battleStream.writeEnd()}}
